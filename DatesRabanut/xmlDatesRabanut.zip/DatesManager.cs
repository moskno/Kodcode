﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace DatesRabanut
{
    internal class DatesManager
    {
        //משתנה
        private XmlDocument _document;
        //בנאי
        public DatesManager(XmlDocument doc)
        {
            _document = doc;
        }

        private XmlNode GetRoot()
        {
            return _document.GetElementsByTagName("Queries")[0];
        }
        public void AddDate(List<string> dates)
        {
            XmlElement dateElement = _document.CreateElement("Query");
            List<string> tagsName = new List<string>()
            {"WeekDay", "MonthDay", "Month", "Year",};
            for (int i = 0; i < tagsName.Count; i++)
            {
                XmlElement child = _document.CreateElement(tagsName[i]);
                child.InnerText = dates[i];
                dateElement.AppendChild(child);
            }
            GetRoot().AppendChild(dateElement);
        }


        public XmlDocument GetDocument()
        {
            return _document;
        }
    }
}
