select Pass, code from Passwords
select IdNumber, code from Employees

--declare @id_number varchar (10) = '';
--declare @old_pass varchar (10) = '';
--declare @new_pass varchar (10) = '';
--declare @valid_new_pass varchar (10) = '';


declare @return_answer varchar (250) = '';


-- ����� �"� ������
if exists (
	select Pass from Passwords
	join Employees on Employees.Code = Passwords.EmployeeCode
	where Employees.IdNumber=@id_number
	and Passwords.Pass = @old_pass
	and Passwords.HAS_ACCESS = 1)
		begin
			if exists (
				select Pass from Passwords
				join Employees on Employees.Code = Passwords.EmployeeCode
				where Employees.IdNumber=@id_number 
				and Passwords.Pass = @old_pass 
				and Passwords.HAS_ACCESS = 1 
				and @new_pass != @old_pass)
					begin
						if exists (
							select Pass from Passwords
							join Employees on Employees.Code = Passwords.EmployeeCode
							where Employees.IdNumber=@id_number 
							and Passwords.Pass = @old_pass 
							and Passwords.HAS_ACCESS = 1 
							and @new_pass = @valid_new_pass)
								begin 
									update Passwords
									set HAS_ACCESS = 0
									from Passwords
									join Employees on Employees.Code = Passwords.EmployeeCode
									where Employees.IdNumber=@id_number
									and Passwords.Pass = @old_pass

									insert into Passwords values
									((select Employees.Code from Employees
									where Employees.IdNumber = @id_number), @new_pass ,DATEADD(day, 180, GETDATE()), 1)
									select @return_answer = 'Your Password has been succsessfully updated';
								end
						else
								begin
									select @return_answer = 'The Valid Password is incorrect, Try again';
								end
					end
			else
					begin 
						select @return_answer = 'The password has already been used, Try a different password';
					end
		end
else
	begin 
		select @return_answer = 'One of the data you entered is incorrect, Please try again';
	end

select @return_answer
