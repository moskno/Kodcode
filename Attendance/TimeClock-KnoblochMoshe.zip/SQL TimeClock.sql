-- Employee table
CREATE TABLE Employees (Code INT PRIMARY KEY IDENTITY,
FullName VARCHAR(30),
IdNumber VARCHAR(10) UNIQUE,
)

-- Password table
CREATE TABLE Passwords (Code INT PRIMARY KEY IDENTITY,
EmployeeCode Int FOREIGN KEY REFERENCES Employees(Code),
Pass VARCHAR(10),
ExpiryDate DATE,
HAS_ACCESS BIT,
)

CREATE TABLE Attendances (Code INT PRIMARY KEY IDENTITY,
EmployeeCode Int FOREIGN KEY REFERENCES Employees(Code),
Date DATE,
EntryTime DATETIME,
ExitTime DATETIME,
)


SELECT * FROM Employees

declare @id VARCHAR(10) = '352993898';
declare @password varchar (10) = '1234';
declare @code int, @answer VARCHAR(250), @fullname VARCHAR(20)='';


IF exists (SELECT * FROM Employees where IdNumber = @id)
	begin
		SELECT @code = (SELECT code FROM Employees where IdNumber = @id)
	end

else
	begin
		insert into Employees  (FullName, IdNumber) values (@FullName, @id);
		select @code = @@IDENTITY;
	end


IF exists (select * from Passwords WHERE EmployeeCode = @code)
	begin
		if exists (select pass From Passwords
		WHERE EmployeeCode = @code AND pass = @password AND HAS_ACCESS = 1)
			begin
				if exists (select pass From Passwords
				WHERE EmployeeCode = @code AND pass = @password AND HAS_ACCESS = 1 AND ExpiryDate>=GETDATE())
					begin
						IF exists (SELECT * FROM Attendances
						WHERE EmployeeCode = @code AND ExitTime is null)
							begin
								UPDATE Attendances set ExitTime = GETDATE()
								WHERE EmployeeCode = @code AND ExitTime is null;
								select @answer = 'exit time' + convert (nvarchar, GETDATE(),121);
							end
						else
							begin
								insert into Attendances VALUES (@code, GETDATE(), GETDATE(), null);
								select @answer = 'entry time' + convert (nvarchar, GETDATE(),121);
							end
						-- ����� \ �����
					end
				else
					begin
						select @answer = 'you need to update your password';
						-- ����� �����
					end
			end
		else
			begin
				select @answer = 'wrong password';
				-- ����� �����
			end
	end
	
	else
		begin
			insert into Passwords values (@code, @password,DATEADD(day, 180,  GETDATE()), 1)
			select @answer = 'you need to create a new password'
		end



-- result code only
--SELECT @code as code_value

--SELECT * FROM Passwords

--SELECT * FROM Attendances







